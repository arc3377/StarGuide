import React, { useState, useRef, useEffect, useCallback } from 'react';
import { StarLightSystem } from './lib/amaterasu';
import { CoreFieldState, CognitiveSystemState, Message, Role, PipelineStage, ClusterState } from './types';
import ChatInterface from './components/ChatInterface';
import SystemStateDisplay from './components/SystemStateDisplay';
import { generateChatResponse } from './services/geminiService';
import { getInitialPipelineState, simulatePipelineRun } from './services/pipelineService';
import { fetchClusterState } from './services/apiService';

const App: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([
        { role: Role.BOT, content: "I am Star Light Guide, a DevOps AI agent. How can I assist with your Kubernetes clusters, CI/CD pipelines, or microservice dashboards today?" }
    ]);
    const [isThinking, setIsThinking] = useState(false);
    const [pipelineStages, setPipelineStages] = useState<PipelineStage[] | null>(null);
    const [isPipelineRunning, setIsPipelineRunning] = useState(false);
    
    const [clusterState, setClusterState] = useState<ClusterState | null>(null);
    const [isClusterLoading, setIsClusterLoading] = useState(true);
    const [clusterError, setClusterError] = useState<string | null>(null);

    const starLightSystem = useRef(new StarLightSystem());

    const [coreState, setCoreState] = useState<CoreFieldState>(
        starLightSystem.current.getCoreState()
    );
    const [cognitiveState, setCognitiveState] = useState<CognitiveSystemState>(
        starLightSystem.current.getCognitiveState()
    );

    useEffect(() => {
        const getClusterData = async () => {
            try {
                setClusterError(null);
                const data = await fetchClusterState();
                setClusterState(data);
            } catch (error) {
                if (error instanceof Error) {
                    setClusterError(error.message);
                } else {
                    setClusterError("An unknown error occurred while fetching cluster data.");
                }
            } finally {
                setIsClusterLoading(false);
            }
        };

        getClusterData(); // Initial fetch
        const interval = setInterval(getClusterData, 5000); // Poll for updates every 5 seconds

        return () => clearInterval(interval);
    }, []);

    const stringToVector = (str: string, dimensions: number): number[] => {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash |= 0; 
        }

        const stimulus = new Array(dimensions).fill(0);
        const stimulusStrength = 0.2;
        const stimulusIndex = Math.abs(hash) % dimensions;
        stimulus[stimulusIndex] = (hash > 0 ? 1 : -1) * stimulusStrength;

        // Apply some spread
        for (let i = 1; i <= 2; i++) {
            const leftIndex = (stimulusIndex - i + dimensions) % dimensions;
            const rightIndex = (stimulusIndex + i) % dimensions;
            stimulus[leftIndex] = (hash > 0 ? 1 : -1) * stimulusStrength / (i + 1);
            stimulus[rightIndex] = (hash > 0 ? 1 : -1) * stimulusStrength / (i + 1);
        }
        
        return stimulus;
    };
    
    const handleSendMessage = useCallback(async (userInput: string) => {
        if (!userInput.trim()) return;

        const userMessage: Message = { role: Role.USER, content: userInput };
        setMessages(prev => [...prev, userMessage]);
        setIsThinking(true);

        const externalInput = stringToVector(userInput, starLightSystem.current.core_dynamics.dimensions);
        
        // Run a few cycles to let the input propagate
        for (let i = 0; i < 5; i++) {
            starLightSystem.current.run_cognitive_cycle(externalInput);
        }
        
        const { patterns, selected_concept } = starLightSystem.current.getLastCycleInfo();
        
        setCoreState(starLightSystem.current.getCoreState());
        setCognitiveState(starLightSystem.current.getCognitiveState());

        try {
            const botResponseContent = await generateChatResponse(selected_concept, patterns);
            const botMessage: Message = { role: Role.BOT, content: botResponseContent };
            setMessages(prev => [...prev, botMessage]);
        } catch (error) {
            console.error("Error generating response:", error);
            const errorMessage: Message = { role: Role.BOT, content: "My core processing is fluctuating... I'm having trouble generating a response. Please try again." };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsThinking(false);
        }
    }, []);

    const handleRunPipeline = useCallback(() => {
        if (isPipelineRunning) return;

        setIsPipelineRunning(true);
        setPipelineStages(getInitialPipelineState());

        simulatePipelineRun(
            (updatedStages) => {
                setPipelineStages([...updatedStages]);
            },
            () => {
                setIsPipelineRunning(false);
            }
        );
    }, [isPipelineRunning]);


    return (
        <div className="flex h-screen w-full font-sans bg-gray-900 text-gray-100">
            <div className="flex flex-col w-full lg:w-2/3 xl:w-3/5 p-4 md:p-6 border-r border-gray-700">
                <header className="mb-4">
                    <h1 className="text-3xl font-bold text-cyan-300">Star Light Guide</h1>
                    <p className="text-gray-400">Your AI partner for Kubernetes, CI/CD, and microservice observability.</p>
                </header>
                <ChatInterface
                    messages={messages}
                    isThinking={isThinking}
                    onSendMessage={handleSendMessage}
                />
            </div>
            <div className="hidden lg:flex flex-col w-1/3 xl:w-2/5 p-4 md:p-6">
                <SystemStateDisplay 
                    coreState={coreState} 
                    cognitiveState={cognitiveState}
                    pipelineStages={pipelineStages}
                    isPipelineRunning={isPipelineRunning}
                    onRunPipeline={handleRunPipeline}
                    clusterState={clusterState}
                    isClusterLoading={isClusterLoading}
                    clusterError={clusterError}
                />
            </div>
        </div>
    );
};

export default App;