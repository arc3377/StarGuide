export enum Role {
    USER = 'user',
    BOT = 'bot',
}

export interface Message {
    role: Role;
    content: string;
}

export interface Patterns {
    variance: number;
    mean_value: number;
    stability: number;
    dominant_freq_idx: number;
}

export interface Concept {
    id: string;
    magnitude: number;
}

export interface CoreFieldState {
    primary_field: number[];
    alpha: number;
    beta: number;
    gamma: number;
    control_gain: number;
    variance_threshold: number;
    time: number;
}

export interface CognitiveSystemState {
    creativity_field: number[];
    logic_field: number[];
    deduction_field: number[];
    patterns: Patterns;
    selected_concept: Concept;
}

export enum PipelineStatus {
    PENDING = 'PENDING',
    RUNNING = 'RUNNING',
    SUCCESS = 'SUCCESS',
    FAILED = 'FAILED',
}

export interface PipelineStage {
    id: string;
    name: string;
    status: PipelineStatus;
    duration?: string;
}

export enum K8sStatus {
    HEALTHY = 'HEALTHY',
    UNHEALTHY = 'UNHEALTHY',
    DEGRADED = 'DEGRADED',
}

export interface K8sNode {
    name: string;
    status: 'Ready' | 'NotReady';
    cpuUsage: number; 
    memoryUsage: number;
}

export interface K8sPod {
    name: string;
    status: 'Running' | 'Pending' | 'Succeeded' | 'Failed' | 'Unknown';
    namespace: string;
    node: string;
}

export interface K8sDeployment {
    name: string;
    namespace: string;
    readyReplicas: number;
    totalReplicas: number;
}

export interface ClusterState {
    status: K8sStatus;
    nodes: K8sNode[];
    pods: K8sPod[];
    deployments: K8sDeployment[];
}
