import React from 'react';
import { CoreFieldState, CognitiveSystemState, PipelineStage, ClusterState } from '../types';
import FieldChart from './FieldChart';
import { BrainCircuit, Zap, PlayCircle, Server } from 'lucide-react';
import PipelineDisplay from './PipelineDisplay';
import KubernetesDisplay from './KubernetesDisplay';

interface SystemStateDisplayProps {
    coreState: CoreFieldState;
    cognitiveState: CognitiveSystemState;
    pipelineStages: PipelineStage[] | null;
    isPipelineRunning: boolean;
    onRunPipeline: () => void;
    clusterState: ClusterState | null;
    isClusterLoading: boolean;
    clusterError: string | null;
}

const MetricCard: React.FC<{ title: string; value: string | number; color: string }> = ({ title, value, color }) => (
    <div className="bg-gray-800 p-3 rounded-lg flex-1 text-center shadow-md">
        <p className="text-sm text-gray-400">{title}</p>
        <p className={`text-xl font-bold ${color}`}>{typeof value === 'number' ? value.toFixed(4) : value}</p>
    </div>
);

const SystemStateDisplay: React.FC<SystemStateDisplayProps> = ({ 
    coreState, 
    cognitiveState,
    pipelineStages,
    isPipelineRunning,
    onRunPipeline,
    clusterState,
    isClusterLoading,
    clusterError
}) => {
    return (
        <div className="flex flex-col h-full w-full bg-gray-800 rounded-lg p-4 space-y-4 overflow-y-auto">
            <header>
                <h2 className="text-2xl font-bold text-cyan-300">DevOps AI Core Monitor</h2>
                <p className="text-sm text-gray-400">Real-time visualization of the Star Light Guide's operational state.</p>
            </header>

            <div className="bg-gray-900/50 p-4 rounded-lg space-y-3">
                <h3 className="font-bold text-lg text-gray-200 flex items-center"><BrainCircuit className="w-5 h-5 mr-2 text-purple-400" />AI Internal State</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <MetricCard title="Stability" value={cognitiveState.patterns.stability} color="text-green-400" />
                    <MetricCard title="System Flux" value={cognitiveState.patterns.variance} color="text-yellow-400" />
                    <MetricCard title="System Baseline" value={cognitiveState.patterns.mean_value} color="text-blue-400" />
                    <MetricCard title="Cycles" value={coreState.time.toFixed(2)} color="text-gray-300" />
                </div>
                 <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Current Directive:</span>
                    <span className="font-mono bg-purple-900/50 text-purple-300 px-2 py-1 rounded">{cognitiveState.selected_concept.id}</span>
                </div>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                    <div className="flex justify-between"><span className="text-gray-400">Alpha (Scalability):</span> <span className="font-mono text-gray-300">{coreState.alpha.toFixed(3)}</span></div>
                    <div className="flex justify-between"><span className="text-gray-400">Beta (Stability):</span> <span className="font-mono text-gray-300">{coreState.beta.toFixed(3)}</span></div>
                </div>
            </div>

            <div className="bg-gray-900/50 p-4 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                     <h3 className="font-bold text-lg text-gray-200">CI/CD Pipeline Simulation</h3>
                     <button
                        onClick={onRunPipeline}
                        disabled={isPipelineRunning}
                        className="flex items-center space-x-2 bg-cyan-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-cyan-600 focus:outline-none focus:ring-2 focus:ring-cyan-400 disabled:bg-cyan-700 disabled:cursor-not-allowed transition-colors"
                     >
                        <PlayCircle className="w-5 h-5" />
                        <span>{isPipelineRunning ? 'Running...' : 'Run Pipeline'}</span>
                     </button>
                </div>
                <PipelineDisplay stages={pipelineStages || []} />
            </div>

            <div className="bg-gray-900/50 p-4 rounded-lg">
                 <h3 className="font-bold text-lg text-gray-200 flex items-center mb-3"><Server className="w-5 h-5 mr-2 text-teal-400" />Kubernetes Cluster Overview</h3>
                 <KubernetesDisplay 
                    clusterState={clusterState}
                    isLoading={isClusterLoading}
                    error={clusterError}
                 />
            </div>
            
            <div className="flex-grow flex flex-col space-y-2 min-h-[300px]">
                <FieldChart title="Primary Operational Field" data={coreState.primary_field} color="#22d3ee" />
                <FieldChart title="Decision Field" data={cognitiveState.deduction_field} color="#c084fc" />
            </div>
        </div>
    );
};

export default SystemStateDisplay;