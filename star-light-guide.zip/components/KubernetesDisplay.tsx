import React from 'react';
import { ClusterState, K8sStatus, K8sNode } from '../types';
import { Server, Cpu, MemoryStick, Box, ShieldCheck, ShieldAlert, ShieldX, CheckCircle2, Loader, XCircle, AlertTriangle } from 'lucide-react';

interface KubernetesDisplayProps {
    clusterState: ClusterState | null;
    isLoading: boolean;
    error: string | null;
}

const statusConfig = {
    [K8sStatus.HEALTHY]: {
        label: 'Healthy',
        Icon: ShieldCheck,
        color: 'text-green-400',
        bgColor: 'bg-green-500/10',
    },
    [K8sStatus.DEGRADED]: {
        label: 'Degraded',
        Icon: ShieldAlert,
        color: 'text-yellow-400',
        bgColor: 'bg-yellow-500/10',
    },
    [K8sStatus.UNHEALTHY]: {
        label: 'Unhealthy',
        Icon: ShieldX,
        color: 'text-red-400',
        bgColor: 'bg-red-500/10',
    },
};

const podStatusIcons = {
    Running: <CheckCircle2 className="w-4 h-4 text-green-400" />,
    Succeeded: <CheckCircle2 className="w-4 h-4 text-gray-400" />,
    Pending: <Loader className="w-4 h-4 text-blue-400 animate-spin" />,
    Failed: <XCircle className="w-4 h-4 text-red-400" />,
    Unknown: <XCircle className="w-4 h-4 text-gray-500" />,
};

const ProgressBar: React.FC<{ value: number }> = ({ value }) => {
    const getColor = () => {
        if (value > 85) return 'bg-red-500';
        if (value > 65) return 'bg-yellow-500';
        return 'bg-green-500';
    };
    return (
        <div className="w-full bg-gray-700 rounded-full h-2">
            <div className={`${getColor()} h-2 rounded-full`} style={{ width: `${value}%` }}></div>
        </div>
    );
};

const SkeletonLoader: React.FC = () => (
    <div className="space-y-4 animate-pulse">
        <div className="flex items-center space-x-3 p-3 rounded-lg bg-gray-700/50">
            <div className="w-6 h-6 rounded-full bg-gray-600"></div>
            <div>
                <div className="h-4 w-24 bg-gray-600 rounded"></div>
                <div className="h-3 w-16 bg-gray-600 rounded mt-1"></div>
            </div>
        </div>
        <div>
            <div className="h-4 w-48 bg-gray-600 rounded mb-2"></div>
            <div className="space-y-3">
                <div className="bg-gray-800/50 p-2 rounded-lg h-16"></div>
                <div className="bg-gray-800/50 p-2 rounded-lg h-16"></div>
                <div className="bg-gray-800/50 p-2 rounded-lg h-16"></div>
            </div>
        </div>
    </div>
);


const KubernetesDisplay: React.FC<KubernetesDisplayProps> = ({ clusterState, isLoading, error }) => {
    if (isLoading && !clusterState) {
        return <SkeletonLoader />;
    }

    if (error) {
        return (
            <div className="bg-red-900/50 border border-red-500 text-red-300 p-4 rounded-lg flex items-start space-x-3">
                <AlertTriangle className="w-6 h-6 flex-shrink-0" />
                <div>
                    <h4 className="font-bold">Connection Error</h4>
                    <p className="text-xs mt-1">{error}</p>
                </div>
            </div>
        );
    }
    
    if (!clusterState) {
        return null;
    }

    const { status, nodes, pods, deployments } = clusterState;
    const config = statusConfig[status];

    const readyNodes = nodes.filter(n => n.status === 'Ready').length;
    
    const podStatusCounts = pods.reduce((acc, pod) => {
        acc[pod.status] = (acc[pod.status] || 0) + 1;
        return acc;
    }, {} as Record<string, number>);

    return (
        <div className="space-y-4 text-sm">
            <div className={`flex items-center space-x-3 p-3 rounded-lg ${config.bgColor}`}>
                <config.Icon className={`w-6 h-6 ${config.color}`} />
                <div>
                    <p className="font-bold text-gray-200">Cluster Status</p>
                    <p className={`${config.color}`}>{config.label}</p>
                </div>
            </div>

            <div>
                <h4 className="font-semibold text-gray-300 mb-2">Nodes ({readyNodes} / {nodes.length} Ready)</h4>
                <div className="space-y-3">
                    {nodes.map(node => (
                        <div key={node.name} className="bg-gray-800/50 p-2 rounded-lg">
                            <div className="flex justify-between items-center mb-2">
                                <div className="flex items-center space-x-2">
                                    <span className={`w-2 h-2 rounded-full ${node.status === 'Ready' ? 'bg-green-400' : 'bg-red-400'}`}></span>
                                    <span className="font-mono text-gray-300">{node.name}</span>
                                </div>
                                <span className={`text-xs font-bold ${node.status === 'Ready' ? 'text-green-400' : 'text-red-400'}`}>{node.status}</span>
                            </div>
                            <div className="grid grid-cols-2 gap-x-4 text-xs">
                                <div className="space-y-1">
                                    <div className="flex items-center justify-between text-gray-400">
                                        <div className="flex items-center"><Cpu className="w-3 h-3 mr-1" /> CPU</div>
                                        <span>{node.cpuUsage.toFixed(0)}%</span>
                                    </div>
                                    <ProgressBar value={node.cpuUsage} />
                                </div>
                                <div className="space-y-1">
                                     <div className="flex items-center justify-between text-gray-400">
                                        <div className="flex items-center"><MemoryStick className="w-3 h-3 mr-1" /> Memory</div>
                                        <span>{node.memoryUsage.toFixed(0)}%</span>
                                    </div>
                                    <ProgressBar value={node.memoryUsage} />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

             <div>
                <h4 className="font-semibold text-gray-300 mb-2">Pods by Status</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {Object.entries(podStatusCounts).map(([podStatus, count]) => (
                        <div key={podStatus} className="bg-gray-800/50 p-2 rounded flex items-center space-x-2">
                             {podStatusIcons[podStatus as keyof typeof podStatusIcons]}
                             <div className="flex-grow">
                                <span className="text-gray-300 text-xs">{podStatus}</span>
                                <p className="font-bold text-lg">{count}</p>
                             </div>
                        </div>
                    ))}
                    {Object.keys(podStatusCounts).length === 0 && <p className="text-gray-400 text-xs col-span-full">No pods found.</p>}
                </div>
            </div>

            <div>
                <h4 className="font-semibold text-gray-300 mb-2">Deployments</h4>
                <div className="space-y-2">
                    {deployments.map(dep => {
                        const isHealthy = dep.readyReplicas === dep.totalReplicas;
                        const isUnhealthy = dep.readyReplicas === 0 && dep.totalReplicas > 0;
                        const healthColor = isUnhealthy ? 'text-red-400' : isHealthy ? 'text-green-400' : 'text-yellow-400';
                        
                        let HealthIcon;
                        if (isUnhealthy) {
                            HealthIcon = <XCircle className={`w-4 h-4 mr-2 flex-shrink-0 ${healthColor}`} />;
                        } else if (isHealthy) {
                            HealthIcon = <CheckCircle2 className={`w-4 h-4 mr-2 flex-shrink-0 ${healthColor}`} />;
                        } else {
                            HealthIcon = <AlertTriangle className={`w-4 h-4 mr-2 flex-shrink-0 ${healthColor}`} />;
                        }

                        return (
                            <div key={dep.name} className="flex justify-between items-center bg-gray-800/50 p-2 rounded">
                                <div className="flex items-center">
                                    {HealthIcon}
                                    <span className="font-mono text-gray-300">{dep.name}</span>
                                </div>
                                <span className={`font-bold ${healthColor}`}>
                                    {dep.readyReplicas} / {dep.totalReplicas}
                                </span>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};

export default KubernetesDisplay;