
import React from 'react';
import { PipelineStage, PipelineStatus } from '../types';
import { CheckCircle2, XCircle, Loader, CircleDot } from 'lucide-react';

interface PipelineDisplayProps {
    stages: PipelineStage[];
}

const statusConfig = {
    [PipelineStatus.SUCCESS]: {
        Icon: CheckCircle2,
        color: 'text-green-400',
        bgColor: 'bg-green-900/50',
        borderColor: 'border-green-500',
    },
    [PipelineStatus.FAILED]: {
        Icon: XCircle,
        color: 'text-red-400',
        bgColor: 'bg-red-900/50',
        borderColor: 'border-red-500',
    },
    [PipelineStatus.RUNNING]: {
        Icon: Loader,
        color: 'text-blue-400',
        bgColor: 'bg-blue-900/50',
        borderColor: 'border-blue-500',
    },
    [PipelineStatus.PENDING]: {
        Icon: CircleDot,
        color: 'text-gray-400',
        bgColor: 'bg-gray-700/50',
        borderColor: 'border-gray-500',
    },
};


const PipelineDisplay: React.FC<PipelineDisplayProps> = ({ stages }) => {
    if (!stages || stages.length === 0) {
        return (
            <div className="flex items-center justify-center h-24 bg-gray-900/50 rounded-lg">
                <p className="text-gray-400">Click "Run Pipeline" to start a simulation.</p>
            </div>
        );
    }
    
    return (
        <div className="flex items-center justify-between space-x-2 md:space-x-4 p-4 overflow-x-auto">
            {stages.map((stage, index) => {
                const { Icon, color, bgColor, borderColor } = statusConfig[stage.status];
                const isLast = index === stages.length - 1;
                const connectorColor = stages[index].status === PipelineStatus.SUCCESS || stages[index].status === PipelineStatus.RUNNING ? 'bg-green-500' : 'bg-gray-600';

                return (
                    <React.Fragment key={stage.id}>
                        <div className="flex flex-col items-center flex-shrink-0 w-28 text-center">
                            <div className={`relative w-12 h-12 rounded-full flex items-center justify-center border-2 ${borderColor} ${bgColor} transition-all duration-300`}>
                                <Icon className={`w-6 h-6 ${color} ${stage.status === PipelineStatus.RUNNING ? 'animate-spin' : ''}`} />
                            </div>
                            <p className={`mt-2 text-xs font-semibold ${color}`}>{stage.name}</p>
                            {stage.duration && <p className="text-xs text-gray-400">{stage.duration}</p>}
                        </div>
                        {!isLast && (
                           <div className={`flex-grow h-1 rounded-full transition-colors duration-500 ${connectorColor}`}></div>
                        )}
                    </React.Fragment>
                );
            })}
        </div>
    );
};

export default PipelineDisplay;
