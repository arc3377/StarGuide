import { GoogleGenAI } from "@google/genai";
import { Concept, Patterns } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

function getPrompt(concept: Concept, patterns: Patterns): string {
    let conceptDescription = "";
    if (concept.id === 'dampen_variance') {
        conceptDescription = "My analysis indicates high system volatility. I am focusing on stabilization protocols and resource optimization to reduce deployment errors and normalize performance.";
    } else if (concept.id === 'drive_syntropy') {
        conceptDescription = "The system is stable, presenting an opportunity for optimization. I am initiating protocols to enhance efficiency, scale resources, or improve pipeline throughput.";
    } else {
        conceptDescription = "I am currently in a monitoring state, observing system telemetry. No immediate action is required.";
    }

    return `
      You are Star Light Guide, a sophisticated AI DevOps assistant specializing in Kubernetes, CI/CD, and microservice architecture.
      Your response must be clear, technical, concise, and actionable. Do not break character.

      Your current internal operational state has just been analyzed with the following results:
      - Current Directive: ${concept.id} (Intensity: ${concept.magnitude.toFixed(4)})
      - Internal Analysis: "${conceptDescription}"
      - System Stability: ${patterns.stability.toFixed(3)} (1.0 is perfectly stable)
      - System Flux (Volatility): ${patterns.variance.toFixed(4)} (higher indicates more flux or instability)

      Based on this internal state and the user's query, formulate your expert response. Provide practical advice, code snippets, or configuration examples where appropriate.
    `;
}

export async function generateChatResponse(concept: Concept, patterns: Patterns): Promise<string> {
    try {
        const prompt = getPrompt(concept, patterns);
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                temperature: 0.5,
                topP: 0.95,
            }
        });
        
        return response.text;
    } catch (error) {
        console.error("Gemini API call failed:", error);
        return "A critical fault occurred in my processing core. I cannot generate a response at this time. Please check system logs.";
    }
}