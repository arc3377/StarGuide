
import { PipelineStage, PipelineStatus } from '../types';

const INITIAL_STAGES: PipelineStage[] = [
    { id: 'clone', name: 'Clone Repository', status: PipelineStatus.PENDING },
    { id: 'build', name: 'Build Application', status: PipelineStatus.PENDING },
    { id: 'test', name: 'Run Unit Tests', status: PipelineStatus.PENDING },
    { id: 'deploy-staging', name: 'Deploy to Staging', status: PipelineStatus.PENDING },
    { id: 'smoke-test', name: 'Smoke Tests', status: PipelineStatus.PENDING },
    { id: 'deploy-prod', name: 'Deploy to Production', status: PipelineStatus.PENDING },
];

export const getInitialPipelineState = (): PipelineStage[] => {
    // Return a deep copy
    return JSON.parse(JSON.stringify(INITIAL_STAGES));
};

export const simulatePipelineRun = (
    onUpdate: (stages: PipelineStage[]) => void,
    onComplete: () => void
) => {
    let currentStages = getInitialPipelineState();
    let currentIndex = 0;
    const failRate = 0.15; // 15% chance to fail at any step after build

    const runNextStage = () => {
        if (currentIndex > 0) {
            const previousStage = currentStages[currentIndex - 1];
            // Check for failure on the just-completed stage
            if (currentIndex > 1 && Math.random() < failRate) {
                previousStage.status = PipelineStatus.FAILED;
                previousStage.duration = `${(Math.random() * 20 + 5).toFixed(1)}s`;
                onUpdate([...currentStages]);
                onComplete();
                return; // Stop the pipeline
            } else {
                 previousStage.status = PipelineStatus.SUCCESS;
                 previousStage.duration = `${(Math.random() * (currentIndex === 1 ? 40 : 20) + 10).toFixed(1)}s`;
            }
        }

        if (currentIndex >= currentStages.length) {
            onUpdate([...currentStages]);
            onComplete();
            return;
        }

        const currentStage = currentStages[currentIndex];
        currentStage.status = PipelineStatus.RUNNING;
        
        onUpdate([...currentStages]);

        const delay = Math.random() * 1000 + 500;
        setTimeout(() => {
            currentIndex++;
            runNextStage();
        }, delay);
    };

    runNextStage();
};
