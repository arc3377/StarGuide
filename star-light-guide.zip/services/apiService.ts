import { ClusterState, K8sStatus, K8sNode, K8sPod, K8sDeployment } from '../types';

// This is a mock database representing the state on a server.
let mockClusterState: ClusterState = {
    status: K8sStatus.HEALTHY,
    nodes: [
        { name: 'gke-main-pool-1-a4b1', status: 'Ready', cpuUsage: 35, memoryUsage: 60 },
        { name: 'gke-main-pool-1-c8d2', status: 'Ready', cpuUsage: 45, memoryUsage: 55 },
        { name: 'gke-main-pool-2-e3f4', status: 'Ready', cpuUsage: 25, memoryUsage: 70 },
    ],
    deployments: [
        { name: 'api-gateway', namespace: 'default', readyReplicas: 3, totalReplicas: 3 },
        { name: 'user-service', namespace: 'default', readyReplicas: 3, totalReplicas: 3 },
        { name: 'product-service', namespace: 'default', readyReplicas: 2, totalReplicas: 3 },
        { name: 'order-service', namespace: 'default', readyReplicas: 3, totalReplicas: 3 },
        { name: 'frontend-app', namespace: 'default', readyReplicas: 5, totalReplicas: 5 },
    ],
    pods: [], // will be generated
};

const generatePods = () => {
    mockClusterState.pods = [];
    mockClusterState.deployments.forEach(dep => {
        for(let i = 0; i < dep.totalReplicas; i++) {
            mockClusterState.pods.push({
                name: `${dep.name}-${Math.random().toString(36).substring(7)}`,
                status: i < dep.readyReplicas ? 'Running' : 'Pending',
                namespace: dep.namespace,
                node: mockClusterState.nodes[i % mockClusterState.nodes.length].name,
            });
        }
    });
}
generatePods(); // Initial generation

const simulateBackendUpdates = () => {
    // Simulate node resource fluctuations
    mockClusterState.nodes.forEach(node => {
        node.cpuUsage = Math.max(10, Math.min(95, node.cpuUsage + (Math.random() - 0.5) * 5));
        node.memoryUsage = Math.max(10, Math.min(95, node.memoryUsage + (Math.random() - 0.5) * 5));
        if (Math.random() < 0.02) { // 2% chance a node becomes NotReady
             if (node.status === 'Ready' && mockClusterState.nodes.filter(n => n.status === 'Ready').length > 1) {
                 node.status = 'NotReady';
             } else {
                 node.status = 'Ready';
             }
        }
    });

    // Simulate pod restarts (crashloop backoff)
    if (mockClusterState.pods.length > 0) {
        const podToRestartIndex = Math.floor(Math.random() * mockClusterState.pods.length);
        if (Math.random() < 0.05) { // 5% chance to restart a pod
            const pod = mockClusterState.pods[podToRestartIndex];
            if (pod.status === 'Running') {
                pod.status = 'Failed';
            }
        } else {
             // Chance for a failed pod to recover
             const failedPod = mockClusterState.pods.find(p => p.status === 'Failed');
             if(failedPod && Math.random() < 0.5) {
                failedPod.status = 'Running';
             }
        }
    }
    
    // Check overall health
    const runningPods = mockClusterState.pods.filter(p => p.status === 'Running').length;
    const totalPods = mockClusterState.pods.length;
    const readyNodes = mockClusterState.nodes.filter(n => n.status === 'Ready').length;
    const totalNodes = mockClusterState.nodes.length;
    const readyDeployments = mockClusterState.deployments.every(d => d.readyReplicas === d.totalReplicas);
    
    if (totalPods > 0 && (runningPods / totalPods < 0.8 || readyNodes < totalNodes)) {
        mockClusterState.status = K8sStatus.UNHEALTHY;
    } else if (totalPods > 0 && (runningPods / totalPods < 0.95 || !readyDeployments)) {
        mockClusterState.status = K8sStatus.DEGRADED;
    } else {
        mockClusterState.status = K8sStatus.HEALTHY;
    }
}

/**
 * Fetches the current state of the Kubernetes cluster.
 * This is a mock API call that simulates network latency and dynamic data.
 * In a real application, this would be an HTTP request to a backend service.
 */
export const fetchClusterState = (): Promise<ClusterState> => {
    return new Promise((resolve, reject) => {
        // Simulate network latency
        setTimeout(() => {
            // Simulate a potential API failure
            if (Math.random() < 0.05) { // 5% chance of failure
                reject(new Error("Failed to connect to the GKE cluster API. Please check your connection and credentials."));
            } else {
                // Simulate the backend generating a new state on each request
                simulateBackendUpdates();
                // Return a deep copy to prevent mutation issues
                resolve(JSON.parse(JSON.stringify(mockClusterState)));
            }
        }, 800 + Math.random() * 500); // realistic latency
    });
};
